import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

def gradient_descent(cost_function, gradient_function, param_range,lr=0.1, initial_params=None, num_iterations=10):
    if initial_params is None:
        initial_params = [np.mean(r) for r in param_range]

    params = list(initial_params)
    best_params = list(initial_params)
    best_cost = cost_function(*initial_params)
    param_values = []
    cost_values = []
    nm = str(cost_function.__name__)
    if len(param_range) == 1:
        x = np.linspace(param_range[0][0], param_range[0][1], 100)
        y = [cost_function(p) for p in x]
        fig, ax = plt.subplots()
        ax.plot(x, y)

        ln_all, = ax.plot([], [], 'ro')
        ln_good, = ax.plot([], [], 'go', markersize=10)

        def onestepderiv(frame):
            nonlocal params, best_params, best_cost
            param_values.append(list(params))
            cost_values.append(cost_function(params[0]))

            params[0] -= gradient_function(params[0]) * lr

            new_cost = cost_function(params[0])

            if new_cost < best_cost:
                best_params[0] = params[0]
                best_cost = new_cost

            ln_all.set_data(param_values, cost_values)
            ln_good.set_data([best_params[0]], [best_cost])

        ani = FuncAnimation(fig, onestepderiv, frames=range(num_iterations), interval=100, repeat=False)
        ani.save(f"{nm}.gif", writer='imagemagick')
        plt.show()


    if len(param_range) == 2:
        x = np.linspace(param_range[0][0], param_range[0][1], 100)
        y = np.linspace(param_range[1][0], param_range[1][1], 100)
        X, Y = np.meshgrid(x, y)
        Z = cost_function(X, Y)

        fig = plt.figure(figsize=(8, 6))
        ax = fig.add_subplot(111, projection='3d')
        ax.plot_surface(X, Y, Z, cmap='viridis')

        ln_all, = ax.plot([], [], [], 'ro-')
        ln_good, = ax.plot([], [], [], 'go', markersize=10)

        def onestepderiv(frame):
            nonlocal params, best_params, best_cost
            param_values.append(list(params))
            cost_values.append(cost_function(*params))
            gradient = gradient_function(*params)

            # Update both x and y parameters
            new_params = [param - grad * lr for param, grad in zip(params, gradient)]
            new_cost = cost_function(*new_params)

            if new_cost < best_cost:
                best_params = new_params
                best_cost = new_cost

            params = new_params
            param_values.append(new_params)
            cost_values.append(new_cost)

            # Separate the X, Y, and Z coordinates for update
            x_values, y_values = zip(*param_values)
            ln_all.set_data(x_values, y_values)
            ln_all.set_3d_properties(cost_values)
            ln_good.set_data([best_params[0]], [best_params[1]])
            ln_good.set_3d_properties([best_cost])

        ani = FuncAnimation(fig, onestepderiv, frames=range(num_iterations), interval=10, repeat=False)
        plt.show()
        ani.save(f"{nm}.gif", writer='imagemagick')

# Example usage:
def f1(x):
    return x ** 2 + 3 * x + 8

def df1_dx(x):
    return 2 * x + 3 

param_range_1d = [(-5, 5)]
gradient_descent(f1, df1_dx, param_range_1d, lr=0.1, initial_params=[3], num_iterations=10)#call the fucking function fucking fucktion
# Example usage:
def f5(x):
    return np.cos(x)**4 - np.sin(x)**3 - 4*np.sin(x)**2 + np.cos(x) + 1

def df5_dx(x):
    return -4*np.sin(x)*np.cos(x)**3 + 3*np.cos(x)*np.sin(x)**2 - 8*np.cos(x)*np.sin(x) - np.sin(x)
param_range_1d = [(0, 2*np.pi)]
gradient_descent(f5, df5_dx, param_range_1d, lr=0.1, initial_params=[3], num_iterations=10)        #call the fucking function fucking fucktion

def f4(x, y):
    return np.exp(-(x - y) ** 2) * np.sin(y)
def df4_dx(x, y):
    # Compute the gradient with respect to x and y
    gradient_x = -2 * np.exp(-(x - y) ** 2) * np.sin(y) * (x - y)
    gradient_y = np.exp(-(x - y) ** 2) * np.cos(y) + 2 * np.exp(-(x - y) ** 2) * np.sin(y) * (x - y)
    
    # Return the gradient as a list
    return [gradient_x, gradient_y]
param_range_2d = [(-np.pi, np.pi), (-np.pi, np.pi)]

gradient_descent(f4, df4_dx, param_range_2d, lr=0.1, initial_params=[-1, -2], num_iterations=10)          #call the fucking function fucking fucktion

# Add other test cases as needed.
xlim4 = [-np.pi, np.pi]
def f3(x,y):
    return x**4 - 16*x**3 + 96*x**2 - 256*x + y**2 - 4*y + 262

def df3_dxy(x, y):
    gradient_x =  4*x**3 - 48*x**2 + 192*x - 256
    gradient_y= 2*y - 4
    return [gradient_x,gradient_y]
param_range_2d=[(-10,10),(-10,10)]
gradient_descent(f3, df3_dxy, param_range_2d, lr=0.1, initial_params=[5, -5], num_iterations=10)         #call the fucking function fucking fucktion