import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Define the function to fit
def f1(x, p0, p1, p2):
    t = x[0]
    a = [item * 2*np.pi/t for item in x[1:]]
    b = [item * 3* 2*np.pi/(t) for item in x[1:]]
    c = [item *5*  2*np.pi/(t) for item in x[1:]]

    return p0 * np.sin(a) + p1 * np.sin(b) + p2 * np.sin(c)

# Define the curvefit function
def curvefit(filename):
    x = []  # List to store x values
    y = []  # List to store y values

    # Open and read the data from the file
    with open(filename, 'r') as file1:
        lines = file1.readlines()
        for line in lines:
            line = line.split()
            x.append(float(line[0]))  # Parse and add x value
            y.append(float(line[1]))  # Parse and add y value
        
        # Detect time periods where y is close to 0.2 or -0.2
        list = []
        i = 0
        for value in y:
            i += 1
            if value <= 0.2 and value >= -0.2:
                list.append(x[i])

        # Calculate expected time periods based on detected points
        expected = []
        for i in range(len(list)):
            expec = list[i] - list[i-1]
            if expec > 2:
                expected.append(expec)

        # Calculate the average time period
        timeperiod = np.average(expected)
        
        # Calculate coefficients for a, b, and c
        b = [item *3* 2*np.pi/(timeperiod) for item in x]
        c = [item *5* 2*np.pi/(timeperiod) for item in x]
        a = [item * 2*np.pi/(timeperiod) for item in x]

        # Create a matrix M with sin(a), sin(b), and sin(c)
        M = np.column_stack([np.sin(a), np.sin(b), np.sin(c)])

        # Use least squares to find coefficients p0, p1, p2
        p, _, _, _ = np.linalg.lstsq(M, y, rcond=None)

        # Create initial guess for curve fitting
        initial_guess = [1, 1, 1]

        # Perform the curve fitting using scipy's curve_fit function
        popt, _ = curve_fit(f1, [timeperiod] + x, y, p0=initial_guess)

        # Generate fitted curves
        yest = f1([timeperiod] + x, p[0], p[1], p[2])
        ycurve = f1([timeperiod] + x, popt[0], popt[1], popt[2])

        # Plot the original data and fitted curves
        plt.plot(x, y, label='original')
        plt.plot(x, yest, label='lstst')
        plt.plot(x, ycurve, label='curvefit')
        plt.legend()
        plt.legend(loc='lower right')
        plt.savefig("figure2.jpg")
        plt.show()
        # Print the estimated parameters
        print(f"The estimated parameters are: {p[0]} * sin(t) + {p[1]} * sin(3t) + {p[2]} * sin(5t)")
        print("Optimized parameters (p0, p1, p2):", popt)

# Specify the input data file
file = 'dataset2.txt'

# Call the curvefit function with the specified file
curvefit(file)
