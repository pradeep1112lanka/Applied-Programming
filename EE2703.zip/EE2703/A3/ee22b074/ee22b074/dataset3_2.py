import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Define the nonlinear function to fit with parameters: c, h, k, t
def nlfunc(x, c, h, k, t):
    # Calculate the function value using the provided formula
    b = [value**3 * c**(-2) * 2 * h * (1 / (np.exp(((h / k) * (value / t))) - 1)) for value in x]
    return b 

# Define the curvefit function
def curvefit(filename):
    x = []  # List to store x values
    y = []  # List to store y values

    # Open and read the data from the file
    with open(filename, 'r') as file1:
        lines = file1.readlines()
        for line in lines:
            line = line.split()
            x.append(float(line[0]))  # Parse and add x value
            y.append(float(line[1]))  # Parse and add y value

    # Initial guesses for 'c', 'h', 'k', and 't' parameters
    initial_guess = [3e10, 6e-34, 1e-23, 5000.0]

    # Perform the curve fitting using scipy's curve_fit function
    popt, _ = curve_fit(nlfunc, x, y, p0=initial_guess)

    # Extract the optimized parameter values
    optimized_c, optimized_h, optimized_k, optimized_t = popt

    # Generate the fitted curve using the optimized parameters
    yest = nlfunc(x, optimized_c, optimized_h, optimized_k, optimized_t)

    # Plot the original data and the fitted curve
    plt.plot(x, y, label='original')
    plt.plot(x, yest, label='fit')
    plt.legend()
    plt.xlabel('x')
    plt.ylabel('y')
    plt.show()

    # Print the optimized parameter values
    print(f"Optimized 'c' value: {optimized_c}")
    print(f"Optimized 'h' value: {optimized_h}")
    print(f"Optimized 'k' value: {optimized_k}")
    print(f"Optimized 't' value: {optimized_t}")

# Specify the input data file
file = 'dataset3.txt'

# Call the curvefit function with the specified file
curvefit(file)