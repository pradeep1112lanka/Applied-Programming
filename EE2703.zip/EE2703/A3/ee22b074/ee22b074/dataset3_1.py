import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Define the nonlinear function to fit
def nlfunc(x, t):
    c = 1.4724e-50
    # Calculate the function value using the provided formula
    b = [value**3 * c * (1 / (np.exp((4.801e-11 * (value / t))) - 1)) for value in x]
    return b

# Define the curvefit function
def curvefit(filename):
    x = []  # List to store x values
    y = []  # List to store y values

    # Open and read the data from the file
    with open(filename, 'r') as file1:
        lines = file1.readlines()
        for line in lines:
            line = line.split()
            x.append(float(line[0]))  # Parse and add x value
            y.append(float(line[1]))  # Parse and add y value
    
    # Initial guess for 't' 
    initial_guess = [5000.0]

    # Perform the curve fitting using scipy's curve_fit function
    popt, _ = curve_fit(nlfunc, x, y, p0=initial_guess)

    # Extract the optimized 't' value
    optimized_t = popt[0]
    
    # Generate the fitted curve using the optimized 't' value
    yest = nlfunc(x, optimized_t)
    
    # Plot the original data and the fitted curve
    plt.plot(x, y, label='original')
    plt.plot(x, yest, label='fitted')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.show()

    # Print the optimized 't' value and the optimized parameters
    print(f"Optimized 't' value: {optimized_t}")
    print("Optimized parameters (t):", popt)

# Specify the input data file
file = 'dataset3.txt'

# Call the curvefit function with the specified file
curvefit(file)