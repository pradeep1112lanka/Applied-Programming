import numpy as np
import matplotlib.pyplot as plt

# Define a function for a straight line equation: y = mx + c
def stline(x, m, c):
    x = np.array(x)
    return m * x + c

# Define a function for curve fitting from a file
def curvefit(filename):
    x = []  # List to store x values
    y = []  # List to store y values
    
    # Open and read the data from the file
    with open(filename, 'r') as file1:
        lines = file1.readlines()
        for line in lines:
            line = line.split()
            x.append(float(line[0]))  # Parse and add x value
            y.append(float(line[1]))  # Parse and add y value
        
        # Create a matrix M with x values and a column of ones
        M = np.column_stack([x, np.ones(len(x))])
        
        # Use the least squares method to find the best-fit line coefficients p1 and p2
        (p1, p2), _, _, _ = np.linalg.lstsq(M, y, rcond=None)
        
        # Generate the estimated y values based on the best-fit line equation
        yest = stline(x, p1, p2)
        
        # Create a plot with original data, estimated data, and error bars
        plt.errorbar(x[::25], y[::25], np.std(x), fmt='ro', label='errorbar')
        plt.plot(x, y, label='original')
        plt.plot(x, yest, label='estimated')
        plt.xlabel('x')
        plt.ylabel('y')
        plt.legend()
        plt.legend(loc='upper left')  # Position the legend in the upper left corner
        plt.show()
        plt.savefig('figure1.png')  
        print(f"The estimated equation is {p1} x + {p2}")
        slope=p1
        intercept=p2
    return slope,intercept

# Specify the input data file
file = r"C:\Users\prade\OneDrive\Desktop\EE2703\A3\ee22b074\ee22b074\dataset1.txt"

# Call the curvefit function with the specified file
curvefit(file)
