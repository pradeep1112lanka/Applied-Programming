# Curve Fitting Examples

This folder contains four Python code examples that demonstrate curve fitting techniques using NumPy and SciPy libraries. Each example deals with a different curve fitting scenario. Below, you'll find descriptions and instructions for running each example.

## Example 1: Simple Curve Fitting

**File:** `dataset1.py`

**Description:** This code fits a straight line (y = mx + c) to a dataset in a text file and plots the original data along with the fitted line.

**Instructions:**

1. Make sure you have NumPy and Matplotlib installed (`pip install numpy matplotlib`).
2. Create a dataset text file (`dataset1.txt`) with x and y values separated by spaces.
3. Run the script using `python dataset1.py`.
4. No limitations to the code.

## Example 2: Curve Fitting with Nonlinear Function

**File:** `dataset2.py`

**Description:** This code fits a nonlinear function to a dataset in a text file and plots the original data along with the fitted curve.

**Instructions:**

1. Same instruction as 1
2. code gives output of the expected and original values and the estimated amplitudes of the sin waves
3. Run the script using `python dataset2.py`.

## Example 3: Optimizing Multiple Parameters

**File:** `dataset3_1.py`

**Description:** This code fits a nonlinear function with multiple parameters to a dataset and optimizes the parameters using SciPy's `curve_fit` function.

**Instructions:**

1. same instruction as 1
2. In this code we defined a function which has preassumed values and gabe the output of the caluclated temperatures
3. Run the script using `python dataset3_!.py`.

## Example 4: Optimizing Multiple Parameters with Modified Function

**File:** `dataset3_2.py`

**Description:** This code is an extension of Example 3, where the nonlinear function now accepts multiple parameters (c, h, k, t) to optimize. It optimizes these parameters using SciPy's `curve_fit` function.

**Instructions:**

1. same instruction as 1
2. this code does not give accurate values of all four parameters and i assumed pretty near values as initial values 
3. Run the script using `python dataset3_2.py`.

Each example includes comments for clarity and explanations of the code's functionality. Feel free to explore and adapt these examples to your specific curve fitting needs.
